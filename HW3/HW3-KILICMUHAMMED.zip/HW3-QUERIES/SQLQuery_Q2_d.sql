--2-d- List all attributes of the students whose first name contains �at�.
SELECT *
FROM STUDENT$
WHERE STUDENT$.fName LIKE '%at%'