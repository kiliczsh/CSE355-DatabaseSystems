 --2-e- List staff ID, first name and last name of married managers who is older than 40 and have at
--least 2 children. Order the list by birthdate.--(CONVERT([smallint],datediff(year,[birthDate],getdate())))UPDATE STAFF$
SET STAFF$.age = DATEDIFF(day,STAFF$.birthDate,GETDATE()) / 365SELECT MANAGER$.staffID AS "Manager ID",STAFF$.fName AS "Manager Name",STAFF$.lName AS  "Manager Surname" FROM MANAGER$
join STAFF$
on MANAGER$.staffID = STAFF$.staffID
WHERE STAFF$.isMarried = 1 AND STAFF$.noOfChildren >=2 AND STAFF$.age >= 40
ORDER BY STAFF$.birthDate
