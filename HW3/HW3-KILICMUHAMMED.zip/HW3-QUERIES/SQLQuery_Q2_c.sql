--2-c  List distinct first and last name of students whose department is Computer Engineering
SELECT DISTINCT STUDENT$.fName as "Student Name", STUDENT$.lName as "Student Surname", DEPARTMENT$.dName as "Departmant Name"
from STUDENT$
join DEPARTMENT$
on DEPARTMENT$.deptCode = STUDENT$.deptCode
WHERE DEPARTMENT$.deptCode LIKE 'CSE'
