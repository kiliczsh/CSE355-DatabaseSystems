/**
2) [10 pts] Update the field age for all players.
*/

UPDATE player
SET age = DATEDIFF(YEAR,birthDate,GETDATE())


/**
3) [20 pts] List the �younger� players whose first name does NOT contain �nec� AND play in �Be%ikta%�.
 �Younger� players are the ones whose ages are less than the average age of all players. Retrieve playerID, firstname + � � + lastname.
*/

SELECT p.playerID, (p.firstName+' '+p.lastName)
FROM player p, player_team pt, team t
WHERE p.playerID=pt.playerID AND pt.teamID=t.teamID
	AND p.firstName NOT LIKE '%nec%'
	AND t.name LIKE 'Be%ikta%'
	AND p.age < (SELECT AVG(plyr.age)
					FROM player plyr)


/**
4) [30 pts] Update all city values of the table team AS: �city� + � #p� + �number of players� +� g� + �number of goals forward� 
(e.g. �?stanbul #p25 g74�). Do NOT forget to include own goals in your calculations.
*/

UPDATE team
SET team.city = ( t.city + ' #p'+CAST(numOfPlayersTable.numOfPlayers AS nvarchar)+' g'+CAST(numOfGoalsTable.numOfGoals AS nvarchar))
FROM team t,
	(SELECT t1.name AS teamName, COUNT(t1.name) AS numOfGoals
		FROM player p1, player_team pt1, team t1, goals g
		WHERE p1.playerID=pt1.playerID AND pt1.teamID=t1.teamID AND g.playerID=p1.playerID
			AND pt1.season LIKE '13-14'
			AND g.isOwnGoal=0
		GROUP BY t1.name
		) AS numOfGoalsTable,
	(SELECT t2.name AS teamName, COUNT(t2.name) AS numOfPlayers
		FROM player p2, player_team pt2, team t2
		WHERE p2.playerID=pt2.playerID AND pt2.teamID=t2.teamID
		AND pt2.season LIKE '13-14'
		GROUP BY t2.name
		) AS numOfPlayersTable
WHERE t.name=numOfGoalsTable.teamName
	AND numOfGoalsTable.teamName=numOfPlayersTable.teamName
SELECT *
FROM team t



/**
5) [40 pts] List the top 10 top scorers. 
Retrieve playerID, first name, last name, number of goals scored, number of matches that player did NOT score a goal, average number of goals per scored matches.
*/


SELECT p.playerID,p.firstName,p.lastName,numberOfGoalsTable.numOfGoalsScored as scored,(SELECT 34-COUNT(DISTINCT goals.matchID) 
  FROM goals
  WHERE goals.playerID=p.playerID
  GROUP BY goals.playerID) AS didNotScoredMatches,
  (SELECT ((numberOfGoalsTable.numOfGoalsScored )/(SELECT COUNT(goals.matchID) FROM goals WHERE goals.playerID=p.playerID GROUP BY goals.playerID))) as AverageGoals
FROM player p,
	(SELECT p.playerID ,COUNT(*) AS numOfGoalsScored FROM goals g,player p, player_team pt WHERE g.playerID=p.playerID AND p.playerID=pt.playerID AND g.isOwnGoal=0 AND pt.season LIKE '13-14'
	GROUP BY p.playerID) AS numberOfGoalsTable
WHERE p.playerID=numberOfGoalsTable.playerID
ORDER BY numberOfGoalsTable.numOfGoalsScored DESC


